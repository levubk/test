import os
import datetime
import traceback
import tensorflow as tf

LogFlag = 2
LogConsole = True
debug_tf = True

ErrorFlag = 0
InfoFlag = 1
DebugFlag = 2
LogFileName = os.path.abspath(os.path.join(os.path.curdir, "logs", "log.text"))
LogFileNameError = os.path.abspath(os.path.join(os.path.curdir, "logs", "error.text"))
def Init():
    out_dir = os.path.abspath(os.path.join(os.path.curdir, "logs"))
    if not os.path.exists(out_dir):
        os.makedirs(out_dir)


def Error(message, exception=None):
    if (LogFlag < ErrorFlag):
        return
    msg = "Error {0}: {1}\n".format(datetime.datetime.now().replace(microsecond=0).isoformat(),
                                   message if exception == None else "{0}\n{1}".format(
                                       message, traceback.format_exc()))
    with open(LogFileName, "a") as f:
        f.write(msg)
    with open(LogFileNameError, "a") as f:
        f.write(msg)
    if (LogConsole):
        print (msg)


def Info(message, exception=None):
    if (LogFlag < InfoFlag):
        return
    msg = "Info {0}: {1}\n".format(datetime.datetime.now().replace(microsecond=0).isoformat(),
                                   message if exception == None else "{0}\n{1}".format(
                                       message, traceback.format_exc()))
    with open(LogFileName, "a") as f:
        f.write(msg)
    if (LogConsole):
        print (msg)


def Debug(message, exception=None):
    if (LogFlag < DebugFlag):
        return
    msg = "Debug {0}: {1}\n".format(datetime.datetime.now().replace(microsecond=0).isoformat(),
                                   message if exception == None else "{0}\n{1}".format(
                                       message, traceback.format_exc()))
    with open(LogFileName, "a") as f:
        f.write(msg)
    if (LogConsole):
        print (msg)

def TFInfo(tfObj, txt=None, eval=True):
    if (LogFlag < InfoFlag or not debug_tf):
        return
    with tf.Session() as sess:
        if (eval):
            message = "name {} shape {} dtype {} eval {}".format(tfObj.name, tfObj.shape, tfObj.dtype, tfObj.eval())
        else:
            message = "name {} shape {} dtype {}".format(tfObj.name, tfObj.shape, tfObj.dtype)
    msg = "TFInfo {0}: {1}\n".format(datetime.datetime.now().replace(microsecond=0).isoformat(),
                                   message if txt == None else "{} - {}".format(
                                       message, txt))
    with open(LogFileName, "a") as f:
        f.write(msg)
    if (LogConsole):
        print (msg)


def TFDebug(tfObj, txt=None, eval=True):
    if (LogFlag < DebugFlag or not debug_tf):
        return
    with tf.Session() as sess:
        if (eval):
            message = "name {} shape {} dtype {} eval {}".format(tfObj.name, tfObj.shape, tfObj.dtype, tfObj.eval())
        else:
            message = "name {} shape {} dtype {}".format(tfObj.name, tfObj.shape, tfObj.dtype)
    msg = "TFDebug {0}: {1}\n".format(datetime.datetime.now().replace(microsecond=0).isoformat(),
                                   message if txt == None else "{} - {}".format(
                                       message, txt))
    with open(LogFileName, "a") as f:
        f.write(msg)
    if (LogConsole):
        print (msg)